const transactionStatus = {
  unpaid: 1,
  paid: 2,
  partial: 3,
};

module.exports = transactionStatus;
