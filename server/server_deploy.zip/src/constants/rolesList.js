const rolesList = {
  admin: 1,
  supervisor: 2,
};

module.exports = rolesList;
