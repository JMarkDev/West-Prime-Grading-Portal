const rolesList = {
  admin: 1,
  instructor: 2,
  student: 3,
};

module.exports = rolesList;
