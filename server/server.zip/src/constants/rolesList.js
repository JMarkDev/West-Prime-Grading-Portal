const rolesList = {
  faculty: 1,
  registrar: 2,
  campus_admin: 3,
  admin: 4,
  office: 5,
  office_staff: 6,
};

module.exports = rolesList;
