const documentStatus = {
  incoming: 1,
  delayed: 2,
  received: 3,
  forwarded: 4,
};

module.exports = documentStatus;
