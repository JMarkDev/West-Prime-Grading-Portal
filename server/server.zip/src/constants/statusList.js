const statusList = {
  pending: 0,
  verified: 1,
};

module.exports = statusList;
