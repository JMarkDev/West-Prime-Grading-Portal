const statusList = {
  pending: 0,
  verified: 1,
  approved: 2,
};

module.exports = statusList;
