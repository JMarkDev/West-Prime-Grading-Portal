module.exports = {
  type: "service_account",
  project_id: "wmsu-esu-document-trackin-egwh",
  private_key_id: "5987dca304af0dc16cb98ab088e8820b584f17fb",
  private_key:
    "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDgtgkFVhGJ3fb4\nliM6Phd2qljdiKCuVuxmWUU4CbgtWcLo/WLtMgi1Sl1myI3Hxgz/Ea8Zr99+fvO/\nOaNXj0XWlhZB6zSvmO+Z4zxahJ++vmeQk4pjf0vlq2mMWPLfWOpwVKG+sgrNAnsH\nilkq+fxerWgsnekxttWajqywQYjCouWM6Y+chgQWY4VQ1kEa7D5aoGsYc4CUtV0L\nVavfJLssK3w24BuusXxG1neXkN1q0w4uhPaNlOk5/kAwbu07uNb0a/MVxzGcCNfn\njpym75aoMZXlrHhzeviojKq5PO/vYQOC6SgprA2ZCK/Mpk7tWazd+EghGhFH6DQt\nx1NWUArhAgMBAAECggEAAfxj3CTmhOeV95ySkUDEGfGvlT4gTuggYNduQNx3oOl5\nmy/llltuR6Vhic9xDtRbkCvEppNHBC38qxqIHLWMwESta83XhmuBZxSSt4lTZNb3\nkPfX1dElv2DuXu3YkCQf1sgtsYLu7ODGK/LzXqmMyxyo1nebDGwda0cyZCChI/iy\ntBKc5D10Gx04ch5IFm+5TZuIv5LXfgtfVaGEhUuUxygT1WiJq6ZaSFej0xiHVq4C\nOJGyrCyisIi5kCjZiDFma1X1wJBAR8w4G/d6uzdWEh3CSwSEe15dJFY/8G18eFK4\n4Ach3/aWRb04FKpQWs1ifLNFePcVouDoJUX5e6xAcQKBgQD9iISgrSTKS4rP4EWu\nG+U1prlwhBniBg4zoprsxYePhinoZDLnfWLNdORQZOJftn0CiQf4jxay5Gu+/Ufg\nXOa44K8w2YfippMNwDI+S5dfwsoU0HRQ3V24VrTS0lSpft1NIvfyBVSuJK2bGybv\nrtI1nQN4E8krKgI5CdBP7NSYEQKBgQDi5bqdLNSu3Us3El+ylepH9Ja8pu3vmpBX\ng3sBCmAPOlU64ISrwM75pxQkDhaVQl42Cz0uq57Jcd7RJGJU3qE6H2Sm0jGexfII\nSGqQKTQCbgeMO0mO+0MQqS+KeUwL2TX4nol3vIs0GuHqLKsX66/O8+8vCEpq3uwT\nUMZOyl6V0QKBgQC+0PnpKIdxDewaypQHF42qlKIrEfGdEKutpyttGroNho+SDZ/W\nZKNxORIBg/xwxxtNRi9OnvsZhxuk8mIfdixcZxbT8FT6fB5fkhD+m8wBUczgX4e7\nuPAppnCP36fCre4HeVMdv29dZdOX0pa6fFxP563NuS6GIybrIPy8uuXC0QKBgAXV\nbD/gSDOawvVOhqFb02M4OavuCs4PRkjJu57iOmgJ0ukpnp+f3HJ0xkLLDe+Wfj+b\neF470WBSii0MZ27RLooFBpx3aQkxA7EM05iTRqANXipP1+tSMH48K1m/FqJzWjzj\nLpuigF29lzNjJJ7/00xZ3ztxViB7TMyOVhrufxIRAoGAHAyrccbr+whnmrynNaqq\nIaWSAqZfkoZYAL0fxBbpI+DZ4iEEvSt7CSvpK2rPlwHffeR0T179BzVx7ZTwMNZ+\nLS8UbVTr0tVFUmXGvXvHiKm2QSt1anixVlFqLsqckDa+BzvmLh5wGTIeydoXRfFQ\nzNTlbWT35Uvt5QuZQlrQ2C4=\n-----END PRIVATE KEY-----\n",
  client_email:
    "wmsu-esu-document-tracker@wmsu-esu-document-trackin-egwh.iam.gserviceaccount.com",
  client_id: "108753276625254309652",
  auth_uri: "https://accounts.google.com/o/oauth2/auth",
  token_uri: "https://oauth2.googleapis.com/token",
  auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
  client_x509_cert_url:
    "https://www.googleapis.com/robot/v1/metadata/x509/wmsu-esu-document-tracker%40wmsu-esu-document-trackin-egwh.iam.gserviceaccount.com",
  universe_domain: "googleapis.com",
};
